#!/bin/bash

# Цвета для красоты
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}>>> Начинаю полную установку бота...${NC}"

# 1. Проверка и установка системных зависимостей
echo -e "--- 1/5 Проверка системных пакетов ---"
sudo apt update -y
sudo apt install python3-venv python3-pip -y

# 2. Создание виртуального окружения
echo -e "--- 2/5 Настройка Python окружения ---"
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
./venv/bin/pip install aiogram

# 3. Настройка конфига (если его нет)
if [ ! -f "config.txt" ]; then
    echo -e "${RED}--- 3/5 Настройка конфига (введите данные) ---${NC}"
    read -p "Введите BOT_TOKEN: (чтобы вставить данные нажимаем ctrl + shift + v)" token
    read -p "Введите GROUP_ID (например -100...): " gid
    read -p "Введите THREAD_ID_KT (номер темы): " tkt
    read -p "Введите THREAD_ID_CT (номер темы): " tct
    
    echo "BOT_TOKEN=$token" > config.txt
    echo "GROUP_ID=$gid" >> config.txt
    echo "THREAD_ID_KT=$tkt" >> config.txt
    echo "THREAD_ID_CT=$tct" >> config.txt
    echo "SAVE_ENABLED=False" >> config.txt
else
    echo -e "--- 3/5 config.txt уже существует, пропускаю ---"
fi

# 4. Настройка автозапуска через Systemd (чтобы работал 24/7)
echo -e "--- 4/5 Настройка автозапуска ---"
USER_NAME=$(whoami)
CUR_DIR=$(pwd)

sudo bash -c "cat <<EOF > /etc/systemd/system/tgbot.service
[Unit]
Description=Telegram Bot Service
After=network.target

[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$CUR_DIR
ExecStart=$CUR_DIR/venv/bin/python3 $CUR_DIR/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF"

sudo systemctl daemon-reload
sudo systemctl enable tgbot
sudo systemctl restart tgbot

# 5. Итог
echo -e "--- 5/5 Финализация ---"
echo -e "${GREEN}=======================================${NC}"
echo -e "${GREEN}БОТ УСПЕШНО ЗАПУЩЕН!${NC}"
echo -e "Если упадет — система сама его поднимет."
echo -e "Посмотреть статус: ${GREEN}sudo systemctl status tgbot${NC}"
echo -e "${GREEN}=======================================${NC}"
